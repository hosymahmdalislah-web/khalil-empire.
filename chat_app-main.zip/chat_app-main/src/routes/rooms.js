const express = require('express');
const router = express.Router();
const {
  createRoom,
  getRooms,
  getRoom,
  joinRoom,
  leaveRoom,
  deleteRoom
} = require('../controllers/roomController');
const { authMiddleware } = require('../middleware/auth');
const { validateRequest, schemas } = require('../middleware/validation');

router.post('/', authMiddleware, validateRequest(schemas.createRoom), createRoom);
router.get('/', authMiddleware, getRooms);
router.get('/:id', authMiddleware, getRoom);
router.post('/:id/join', authMiddleware, joinRoom);
router.post('/:id/leave', authMiddleware, leaveRoom);
router.delete('/:id', authMiddleware, deleteRoom);

module.exports = router;
