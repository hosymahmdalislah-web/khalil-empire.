const express = require('express');
const router = express.Router();
const {
  getMessages,
  sendMessage,
  deleteMessage,
  editMessage
} = require('../controllers/messageController');
const { authMiddleware } = require('../middleware/auth');

router.get('/:roomId', authMiddleware, getMessages);
router.post('/', authMiddleware, sendMessage);
router.delete('/:id', authMiddleware, deleteMessage);
router.put('/:id', authMiddleware, editMessage);

module.exports = router;
