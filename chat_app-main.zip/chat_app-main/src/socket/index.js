const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Message = require('../models/Message');
const Room = require('../models/Room');
const config = require('../config');
const logger = require('../config/logger');

const connectedUsers = new Map();

const initializeSocket = (io) => {
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth.token;
      if (!token) {
        return next(new Error('Authentication error'));
      }

      const decoded = jwt.verify(token, config.jwt.secret);
      const user = await User.findById(decoded.userId);

      if (!user || !user.isActive) {
        return next(new Error('Authentication error'));
      }

      socket.userId = user._id.toString();
      socket.user = user;
      next();
    } catch (error) {
      next(new Error('Authentication error'));
    }
  });

  io.on('connection', async (socket) => {
    logger.info(`User connected: ${socket.user.username}`);

    connectedUsers.set(socket.userId, socket.id);

    await User.findByIdAndUpdate(socket.userId, {
      status: 'online',
      lastSeen: new Date()
    });

    io.emit('user:status', {
      userId: socket.userId,
      username: socket.user.username,
      status: 'online'
    });

    socket.on('room:join', async (data) => {
      try {
        const { roomId } = data;
        const room = await Room.findById(roomId);

        if (!room) {
          socket.emit('error', { message: 'Room not found' });
          return;
        }

        if (!room.members.includes(socket.userId)) {
          room.members.push(socket.userId);
          await room.save();
        }

        socket.join(roomId);
        
        const systemMessage = new Message({
          content: `${socket.user.username} joined the room`,
          type: 'system',
          sender: socket.userId,
          room: roomId
        });
        await systemMessage.save();

        io.to(roomId).emit('room:user-joined', {
          user: {
            _id: socket.userId,
            username: socket.user.username,
            displayName: socket.user.displayName
          },
          message: systemMessage
        });

        logger.info(`User ${socket.user.username} joined room ${roomId}`);
      } catch (error) {
        logger.error('Error joining room:', error);
        socket.emit('error', { message: 'Failed to join room' });
      }
    });

    socket.on('room:leave', async (data) => {
      try {
        const { roomId } = data;
        socket.leave(roomId);

        const systemMessage = new Message({
          content: `${socket.user.username} left the room`,
          type: 'system',
          sender: socket.userId,
          room: roomId
        });
        await systemMessage.save();

        io.to(roomId).emit('room:user-left', {
          userId: socket.userId,
          username: socket.user.username,
          message: systemMessage
        });

        logger.info(`User ${socket.user.username} left room ${roomId}`);
      } catch (error) {
        logger.error('Error leaving room:', error);
      }
    });

    socket.on('message:send', async (data) => {
      try {
        const { content, roomId, type } = data;

        const room = await Room.findById(roomId);
        if (!room || !room.members.includes(socket.userId)) {
          socket.emit('error', { message: 'Not authorized' });
          return;
        }

        const message = new Message({
          content,
          type: type || 'text',
          sender: socket.userId,
          room: roomId
        });

        await message.save();
        await message.populate('sender', 'username displayName avatar');

        io.to(roomId).emit('message:new', message);

        logger.info(`Message sent in room ${roomId} by ${socket.user.username}`);
      } catch (error) {
        logger.error('Error sending message:', error);
        socket.emit('error', { message: 'Failed to send message' });
      }
    });

    socket.on('message:typing', (data) => {
      const { roomId, isTyping } = data;
      socket.to(roomId).emit('user:typing', {
        userId: socket.userId,
        username: socket.user.username,
        isTyping
      });
    });

    socket.on('message:private', async (data) => {
      try {
        const { content, recipientId, roomId } = data;

        const message = new Message({
          content,
          type: 'text',
          sender: socket.userId,
          recipient: recipientId,
          room: roomId
        });

        await message.save();
        await message.populate('sender', 'username displayName avatar');

        const recipientSocketId = connectedUsers.get(recipientId);
        if (recipientSocketId) {
          io.to(recipientSocketId).emit('message:private', message);
        }

        socket.emit('message:private', message);
      } catch (error) {
        logger.error('Error sending private message:', error);
        socket.emit('error', { message: 'Failed to send private message' });
      }
    });

    socket.on('disconnect', async () => {
      logger.info(`User disconnected: ${socket.user.username}`);

      connectedUsers.delete(socket.userId);

      await User.findByIdAndUpdate(socket.userId, {
        status: 'offline',
        lastSeen: new Date()
      });

      io.emit('user:status', {
        userId: socket.userId,
        username: socket.user.username,
        status: 'offline'
      });
    });
  });

  return io;
};

module.exports = initializeSocket;
