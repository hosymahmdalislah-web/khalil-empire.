const Room = require('../models/Room');
const Message = require('../models/Message');

const createRoom = async (req, res) => {
  try {
    const { name, description, type, maxMembers } = req.body;

    const room = new Room({
      name,
      description,
      type: type || 'public',
      createdBy: req.user._id,
      members: [req.user._id],
      maxMembers: maxMembers || 50
    });

    await room.save();

    res.status(201).json({
      message: 'Room created successfully',
      room
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getRooms = async (req, res) => {
  try {
    const { type } = req.query;
    const filter = { isActive: true };

    if (type) {
      filter.type = type;
    }

    const rooms = await Room.find(filter)
      .populate('createdBy', 'username displayName')
      .sort({ createdAt: -1 });

    res.json({ rooms });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getRoom = async (req, res) => {
  try {
    const room = await Room.findById(req.params.id)
      .populate('createdBy', 'username displayName avatar')
      .populate('members', 'username displayName avatar status');

    if (!room) {
      return res.status(404).json({ error: 'Room not found' });
    }

    res.json({ room });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const joinRoom = async (req, res) => {
  try {
    const room = await Room.findById(req.params.id);

    if (!room) {
      return res.status(404).json({ error: 'Room not found' });
    }

    if (room.members.includes(req.user._id)) {
      return res.status(400).json({ error: 'Already a member' });
    }

    if (room.members.length >= room.maxMembers) {
      return res.status(400).json({ error: 'Room is full' });
    }

    room.members.push(req.user._id);
    await room.save();

    res.json({
      message: 'Joined room successfully',
      room
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const leaveRoom = async (req, res) => {
  try {
    const room = await Room.findById(req.params.id);

    if (!room) {
      return res.status(404).json({ error: 'Room not found' });
    }

    room.members = room.members.filter(
      member => member.toString() !== req.user._id.toString()
    );
    await room.save();

    res.json({
      message: 'Left room successfully'
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const deleteRoom = async (req, res) => {
  try {
    const room = await Room.findById(req.params.id);

    if (!room) {
      return res.status(404).json({ error: 'Room not found' });
    }

    if (room.createdBy.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Not authorized' });
    }

    room.isActive = false;
    await room.save();

    res.json({
      message: 'Room deleted successfully'
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = {
  createRoom,
  getRooms,
  getRoom,
  joinRoom,
  leaveRoom,
  deleteRoom
};
