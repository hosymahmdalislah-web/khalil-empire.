const Joi = require('joi');

const validateRequest = (schema) => {
  return (req, res, next) => {
    const { error } = schema.validate(req.body, { abortEarly: false });
    
    if (error) {
      const errors = error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message
      }));
      return res.status(400).json({ errors });
    }
    
    next();
  };
};

const schemas = {
  register: Joi.object({
    username: Joi.string().min(3).max(30).required(),
    email: Joi.string().email().required(),
    password: Joi.string().min(6).required(),
    displayName: Joi.string().max(50)
  }),
  
  login: Joi.object({
    username: Joi.string().required(),
    password: Joi.string().required()
  }),
  
  createRoom: Joi.object({
    name: Joi.string().max(100).required(),
    description: Joi.string().max(500),
    type: Joi.string().valid('public', 'private'),
    maxMembers: Joi.number().min(2).max(1000)
  }),
  
  sendMessage: Joi.object({
    content: Joi.string().max(5000).required(),
    type: Joi.string().valid('text', 'file', 'image'),
    roomId: Joi.string().required(),
    recipientId: Joi.string()
  })
};

module.exports = { validateRequest, schemas };
