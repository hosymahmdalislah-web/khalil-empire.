require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../models/User');
const Room = require('../models/Room');
const Message = require('../models/Message');
const logger = require('../config/logger');

const seedData = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/chat_app', {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });

    logger.info('Database connected');

    await User.deleteMany({});
    await Room.deleteMany({});
    await Message.deleteMany({});

    logger.info('Existing data cleared');

    const admin = await User.create({
      username: 'admin',
      email: 'admin@chatapp.com',
      password: 'admin123',
      displayName: 'Administrator',
      role: 'admin'
    });

    const users = await User.create([
      {
        username: 'john_doe',
        email: 'john@example.com',
        password: 'password123',
        displayName: 'John Doe'
      },
      {
        username: 'jane_smith',
        email: 'jane@example.com',
        password: 'password123',
        displayName: 'Jane Smith'
      },
      {
        username: 'bob_wilson',
        email: 'bob@example.com',
        password: 'password123',
        displayName: 'Bob Wilson'
      }
    ]);

    logger.info(`Created ${users.length + 1} users`);

    const rooms = await Room.create([
      {
        name: 'General',
        description: 'General discussion room',
        type: 'public',
        createdBy: admin._id,
        members: [admin._id, ...users.map(u => u._id)]
      },
      {
        name: 'Random',
        description: 'Random chat and off-topic discussions',
        type: 'public',
        createdBy: admin._id,
        members: [admin._id, users[0]._id, users[1]._id]
      },
      {
        name: 'Tech Talk',
        description: 'Technology and programming discussions',
        type: 'public',
        createdBy: users[0]._id,
        members: [users[0]._id, users[2]._id]
      }
    ]);

    logger.info(`Created ${rooms.length} rooms`);

    const messages = await Message.create([
      {
        content: 'Welcome to the chat app!',
        type: 'system',
        sender: admin._id,
        room: rooms[0]._id
      },
      {
        content: 'Hello everyone!',
        type: 'text',
        sender: users[0]._id,
        room: rooms[0]._id
      },
      {
        content: 'Hi there! How is everyone doing?',
        type: 'text',
        sender: users[1]._id,
        room: rooms[0]._id
      }
    ]);

    logger.info(`Created ${messages.length} messages`);

    logger.info('Seed data created successfully!');
    logger.info('\nDefault credentials:');
    logger.info('Admin - username: admin, password: admin123');
    logger.info('User 1 - username: john_doe, password: password123');
    logger.info('User 2 - username: jane_smith, password: password123');
    logger.info('User 3 - username: bob_wilson, password: password123');

    process.exit(0);
  } catch (error) {
    logger.error('Error seeding data:', error);
    process.exit(1);
  }
};

seedData();
