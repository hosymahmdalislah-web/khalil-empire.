const API_URL = window.location.origin + '/api';
let authToken = localStorage.getItem('authToken');
let currentUser = null;

document.addEventListener('DOMContentLoaded', () => {
    if (!authToken) {
        window.location.href = '/';
        return;
    }

    verifyAdmin();
    setupEventListeners();
});

function setupEventListeners() {
    document.getElementById('admin-logout').addEventListener('click', handleLogout);
}

async function verifyAdmin() {
    try {
        const response = await fetch(`${API_URL}/auth/profile`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            currentUser = data.user;

            if (currentUser.role !== 'admin') {
                alert('Admin access required');
                window.location.href = '/';
                return;
            }

            document.getElementById('admin-username').textContent = currentUser.username;
            loadDashboardData();
        } else {
            window.location.href = '/';
        }
    } catch (error) {
        console.error('Verification failed:', error);
        window.location.href = '/';
    }
}

async function loadDashboardData() {
    await Promise.all([
        loadStats(),
        loadUsers(),
        loadRooms(),
        loadMessages()
    ]);
}

async function loadStats() {
    try {
        const response = await fetch(`${API_URL}/admin/stats`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            document.getElementById('total-users').textContent = data.stats.totalUsers;
            document.getElementById('active-users').textContent = data.stats.activeUsers;
            document.getElementById('total-rooms').textContent = data.stats.totalRooms;
            document.getElementById('total-messages').textContent = data.stats.totalMessages;
        }
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

async function loadUsers() {
    try {
        const response = await fetch(`${API_URL}/admin/users`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            displayUsers(data.users);
        }
    } catch (error) {
        console.error('Error loading users:', error);
    }
}

function displayUsers(users) {
    const tbody = document.getElementById('users-table-body');
    
    if (users.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7">No users found</td></tr>';
        return;
    }

    tbody.innerHTML = users.map(user => `
        <tr>
            <td>${user.username}</td>
            <td>${user.email}</td>
            <td>${user.displayName || '-'}</td>
            <td><span class="badge ${user.role}">${user.role}</span></td>
            <td><span class="badge ${user.status}">${user.status}</span></td>
            <td>${new Date(user.createdAt).toLocaleDateString()}</td>
            <td>
                ${user.role !== 'admin' ? `
                    <button class="btn btn-small btn-danger" onclick="deactivateUser('${user._id}')">
                        Deactivate
                    </button>
                ` : ''}
            </td>
        </tr>
    `).join('');
}

async function loadRooms() {
    try {
        const response = await fetch(`${API_URL}/admin/rooms`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            displayRooms(data.rooms);
        }
    } catch (error) {
        console.error('Error loading rooms:', error);
    }
}

function displayRooms(rooms) {
    const tbody = document.getElementById('rooms-table-body');
    
    if (rooms.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5">No rooms found</td></tr>';
        return;
    }

    tbody.innerHTML = rooms.map(room => `
        <tr>
            <td>${room.name}</td>
            <td><span class="badge ${room.type}">${room.type}</span></td>
            <td>${room.members.length}</td>
            <td>${room.createdBy?.username || 'Unknown'}</td>
            <td>${new Date(room.createdAt).toLocaleDateString()}</td>
        </tr>
    `).join('');
}

async function loadMessages() {
    try {
        const response = await fetch(`${API_URL}/admin/messages`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            displayMessages(data.messages);
        }
    } catch (error) {
        console.error('Error loading messages:', error);
    }
}

function displayMessages(messages) {
    const tbody = document.getElementById('messages-table-body');
    
    if (messages.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5">No messages found</td></tr>';
        return;
    }

    tbody.innerHTML = messages.map(message => `
        <tr>
            <td>${message.sender?.username || 'Unknown'}</td>
            <td>${message.room?.name || 'Unknown'}</td>
            <td>${message.content.substring(0, 100)}${message.content.length > 100 ? '...' : ''}</td>
            <td>${new Date(message.createdAt).toLocaleString()}</td>
            <td>
                ${!message.isDeleted ? `
                    <button class="btn btn-small btn-danger" onclick="deleteMessage('${message._id}')">
                        Delete
                    </button>
                ` : '<span class="badge offline">Deleted</span>'}
            </td>
        </tr>
    `).join('');
}

async function deactivateUser(userId) {
    if (!confirm('Are you sure you want to deactivate this user?')) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/admin/users/${userId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            alert('User deactivated successfully');
            loadUsers();
            loadStats();
        } else {
            alert('Failed to deactivate user');
        }
    } catch (error) {
        console.error('Error deactivating user:', error);
        alert('Failed to deactivate user');
    }
}

async function deleteMessage(messageId) {
    if (!confirm('Are you sure you want to delete this message?')) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/messages/${messageId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            alert('Message deleted successfully');
            loadMessages();
            loadStats();
        } else {
            alert('Failed to delete message');
        }
    } catch (error) {
        console.error('Error deleting message:', error);
        alert('Failed to delete message');
    }
}

function handleLogout() {
    localStorage.removeItem('authToken');
    window.location.href = '/';
}
