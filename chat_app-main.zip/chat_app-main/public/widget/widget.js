(function() {
    'use strict';

    const CHAT_API_URL = 'http://localhost:3000/api';
    const SOCKET_URL = 'http://localhost:3000';

    class ChatWidget {
        constructor(config = {}) {
            this.config = {
                position: config.position || 'bottom-right',
                theme: config.theme || 'light',
                primaryColor: config.primaryColor || '#4f46e5',
                roomId: config.roomId,
                width: config.width || '400px',
                height: config.height || '600px',
                ...config
            };

            this.isOpen = false;
            this.socket = null;
            this.token = null;
            this.currentUser = null;

            this.init();
        }

        init() {
            this.injectStyles();
            this.createWidget();
            this.setupEventListeners();
        }

        injectStyles() {
            const styles = `
                .chat-widget-container {
                    position: fixed;
                    ${this.config.position.includes('bottom') ? 'bottom: 20px;' : 'top: 20px;'}
                    ${this.config.position.includes('right') ? 'right: 20px;' : 'left: 20px;'}
                    z-index: 9999;
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                }

                .chat-widget-button {
                    width: 60px;
                    height: 60px;
                    border-radius: 30px;
                    background: ${this.config.primaryColor};
                    color: white;
                    border: none;
                    cursor: pointer;
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 24px;
                    transition: transform 0.3s;
                }

                .chat-widget-button:hover {
                    transform: scale(1.1);
                }

                .chat-widget-window {
                    position: absolute;
                    ${this.config.position.includes('bottom') ? 'bottom: 70px;' : 'top: 70px;'}
                    ${this.config.position.includes('right') ? 'right: 0;' : 'left: 0;'}
                    width: ${this.config.width};
                    height: ${this.config.height};
                    background: white;
                    border-radius: 12px;
                    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
                    display: none;
                    flex-direction: column;
                    overflow: hidden;
                }

                .chat-widget-window.open {
                    display: flex;
                }

                .chat-widget-header {
                    background: ${this.config.primaryColor};
                    color: white;
                    padding: 16px;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }

                .chat-widget-header h3 {
                    margin: 0;
                    font-size: 16px;
                }

                .chat-widget-close {
                    background: none;
                    border: none;
                    color: white;
                    font-size: 24px;
                    cursor: pointer;
                    padding: 0;
                    width: 30px;
                    height: 30px;
                }

                .chat-widget-messages {
                    flex: 1;
                    overflow-y: auto;
                    padding: 16px;
                    background: #f9fafb;
                }

                .chat-widget-message {
                    margin-bottom: 12px;
                    display: flex;
                    flex-direction: column;
                }

                .chat-widget-message.own {
                    align-items: flex-end;
                }

                .chat-widget-message-content {
                    background: white;
                    padding: 10px 14px;
                    border-radius: 12px;
                    max-width: 70%;
                    word-wrap: break-word;
                    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
                }

                .chat-widget-message.own .chat-widget-message-content {
                    background: ${this.config.primaryColor};
                    color: white;
                }

                .chat-widget-message-sender {
                    font-size: 12px;
                    color: #6b7280;
                    margin-bottom: 4px;
                }

                .chat-widget-input-container {
                    padding: 16px;
                    background: white;
                    border-top: 1px solid #e5e7eb;
                    display: flex;
                    gap: 8px;
                }

                .chat-widget-input {
                    flex: 1;
                    padding: 10px;
                    border: 1px solid #e5e7eb;
                    border-radius: 8px;
                    font-size: 14px;
                    outline: none;
                }

                .chat-widget-input:focus {
                    border-color: ${this.config.primaryColor};
                }

                .chat-widget-send {
                    background: ${this.config.primaryColor};
                    color: white;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 8px;
                    cursor: pointer;
                    font-size: 14px;
                    font-weight: 500;
                }

                .chat-widget-send:hover {
                    opacity: 0.9;
                }

                .chat-widget-login {
                    padding: 20px;
                }

                .chat-widget-login input {
                    width: 100%;
                    padding: 10px;
                    margin-bottom: 10px;
                    border: 1px solid #e5e7eb;
                    border-radius: 8px;
                    font-size: 14px;
                }

                .chat-widget-login button {
                    width: 100%;
                    background: ${this.config.primaryColor};
                    color: white;
                    border: none;
                    padding: 12px;
                    border-radius: 8px;
                    cursor: pointer;
                    font-size: 14px;
                    font-weight: 500;
                }
            `;

            const styleElement = document.createElement('style');
            styleElement.textContent = styles;
            document.head.appendChild(styleElement);
        }

        createWidget() {
            const container = document.createElement('div');
            container.className = 'chat-widget-container';
            container.innerHTML = `
                <button class="chat-widget-button" id="chat-widget-toggle">
                    💬
                </button>
                <div class="chat-widget-window" id="chat-widget-window">
                    <div class="chat-widget-header">
                        <h3>Chat Support</h3>
                        <button class="chat-widget-close" id="chat-widget-close">&times;</button>
                    </div>
                    <div id="chat-widget-content">
                        <div class="chat-widget-login" id="chat-widget-login">
                            <input type="text" id="chat-widget-username" placeholder="Username" />
                            <input type="password" id="chat-widget-password" placeholder="Password" />
                            <button id="chat-widget-login-btn">Login</button>
                        </div>
                    </div>
                </div>
            `;

            document.body.appendChild(container);
        }

        setupEventListeners() {
            document.getElementById('chat-widget-toggle').addEventListener('click', () => this.toggle());
            document.getElementById('chat-widget-close').addEventListener('click', () => this.close());
            document.getElementById('chat-widget-login-btn').addEventListener('click', () => this.login());
        }

        toggle() {
            this.isOpen = !this.isOpen;
            const window = document.getElementById('chat-widget-window');
            window.classList.toggle('open', this.isOpen);
        }

        close() {
            this.isOpen = false;
            document.getElementById('chat-widget-window').classList.remove('open');
        }

        async login() {
            const username = document.getElementById('chat-widget-username').value;
            const password = document.getElementById('chat-widget-password').value;

            try {
                const response = await fetch(`${CHAT_API_URL}/auth/login`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username, password })
                });

                if (response.ok) {
                    const data = await response.json();
                    this.token = data.token;
                    this.currentUser = data.user;
                    this.showChatInterface();
                    this.connectSocket();
                }
            } catch (error) {
                console.error('Login failed:', error);
            }
        }

        showChatInterface() {
            const content = document.getElementById('chat-widget-content');
            content.innerHTML = `
                <div class="chat-widget-messages" id="chat-widget-messages"></div>
                <div class="chat-widget-input-container">
                    <input type="text" class="chat-widget-input" id="chat-widget-message-input" placeholder="Type a message..." />
                    <button class="chat-widget-send" id="chat-widget-send-btn">Send</button>
                </div>
            `;

            document.getElementById('chat-widget-send-btn').addEventListener('click', () => this.sendMessage());
            document.getElementById('chat-widget-message-input').addEventListener('keypress', (e) => {
                if (e.key === 'Enter') this.sendMessage();
            });

            if (this.config.roomId) {
                this.joinRoom(this.config.roomId);
            }
        }

        connectSocket() {
            this.socket = io(SOCKET_URL, {
                auth: { token: this.token }
            });

            this.socket.on('message:new', (message) => {
                this.displayMessage(message);
            });
        }

        async joinRoom(roomId) {
            if (this.socket) {
                this.socket.emit('room:join', { roomId });
                await this.loadMessages(roomId);
            }
        }

        async loadMessages(roomId) {
            try {
                const response = await fetch(`${CHAT_API_URL}/messages/${roomId}`, {
                    headers: { 'Authorization': `Bearer ${this.token}` }
                });

                if (response.ok) {
                    const data = await response.json();
                    data.messages.forEach(msg => this.displayMessage(msg));
                }
            } catch (error) {
                console.error('Error loading messages:', error);
            }
        }

        displayMessage(message) {
            const container = document.getElementById('chat-widget-messages');
            const isOwn = message.sender._id === this.currentUser._id;

            const messageEl = document.createElement('div');
            messageEl.className = `chat-widget-message ${isOwn ? 'own' : ''}`;
            messageEl.innerHTML = `
                ${!isOwn ? `<div class="chat-widget-message-sender">${message.sender.username}</div>` : ''}
                <div class="chat-widget-message-content">${message.content}</div>
            `;

            container.appendChild(messageEl);
            container.scrollTop = container.scrollHeight;
        }

        sendMessage() {
            const input = document.getElementById('chat-widget-message-input');
            const content = input.value.trim();

            if (content && this.socket && this.config.roomId) {
                this.socket.emit('message:send', {
                    content,
                    roomId: this.config.roomId,
                    type: 'text'
                });
                input.value = '';
            }
        }
    }

    window.ChatWidget = ChatWidget;

    if (window.chatWidgetConfig) {
        new ChatWidget(window.chatWidgetConfig);
    }
})();
