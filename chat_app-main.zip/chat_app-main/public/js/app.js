const API_URL = window.location.origin + '/api';
let socket = null;
let currentUser = null;
let currentRoom = null;
let authToken = localStorage.getItem('authToken');

// DOM Elements
const authContainer = document.getElementById('auth-container');
const chatContainer = document.getElementById('chat-container');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const createRoomModal = document.getElementById('create-room-modal');
const createRoomForm = document.getElementById('create-room-form');
const roomsList = document.getElementById('rooms-list');
const messagesContainer = document.getElementById('messages-container');
const messageInput = document.getElementById('message-input');
const sendBtn = document.getElementById('send-btn');
const currentUsername = document.getElementById('current-username');
const currentRoomName = document.getElementById('current-room-name');
const roomMembersCount = document.getElementById('room-members-count');
const typingIndicator = document.getElementById('typing-indicator');
const logoutBtn = document.getElementById('logout-btn');
const createRoomBtn = document.getElementById('create-room-btn');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    setupAuthTabs();
    setupEventListeners();
    
    if (authToken) {
        verifyToken();
    }
});

// Auth Tabs
function setupAuthTabs() {
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const targetTab = tab.dataset.tab;
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            document.querySelectorAll('.auth-form').forEach(form => {
                form.classList.remove('active');
            });
            document.getElementById(`${targetTab}-form`).classList.add('active');
        });
    });
}

// Event Listeners
function setupEventListeners() {
    loginForm.addEventListener('submit', handleLogin);
    registerForm.addEventListener('submit', handleRegister);
    createRoomForm.addEventListener('submit', handleCreateRoom);
    sendBtn.addEventListener('click', handleSendMessage);
    messageInput.addEventListener('keypress', handleMessageKeyPress);
    messageInput.addEventListener('input', handleTyping);
    logoutBtn.addEventListener('click', handleLogout);
    createRoomBtn.addEventListener('click', () => {
        createRoomModal.classList.remove('hidden');
    });

    document.querySelector('.close-modal').addEventListener('click', () => {
        createRoomModal.classList.add('hidden');
    });
}

// Verify Token
async function verifyToken() {
    try {
        const response = await fetch(`${API_URL}/auth/profile`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            currentUser = data.user;
            showChatInterface();
        } else {
            localStorage.removeItem('authToken');
            authToken = null;
        }
    } catch (error) {
        console.error('Token verification failed:', error);
        localStorage.removeItem('authToken');
        authToken = null;
    }
}

// Handle Login
async function handleLogin(e) {
    e.preventDefault();
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;
    const errorDiv = document.getElementById('login-error');

    try {
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();

        if (response.ok) {
            authToken = data.token;
            currentUser = data.user;
            localStorage.setItem('authToken', authToken);
            showChatInterface();
            errorDiv.textContent = '';
        } else {
            errorDiv.textContent = data.error || 'Login failed';
        }
    } catch (error) {
        errorDiv.textContent = 'Network error. Please try again.';
    }
}

// Handle Register
async function handleRegister(e) {
    e.preventDefault();
    const username = document.getElementById('register-username').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const displayName = document.getElementById('register-displayname').value;
    const errorDiv = document.getElementById('register-error');

    try {
        const response = await fetch(`${API_URL}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, password, displayName })
        });

        const data = await response.json();

        if (response.ok) {
            authToken = data.token;
            currentUser = data.user;
            localStorage.setItem('authToken', authToken);
            showChatInterface();
            errorDiv.textContent = '';
        } else {
            errorDiv.textContent = data.error || 'Registration failed';
        }
    } catch (error) {
        errorDiv.textContent = 'Network error. Please try again.';
    }
}

// Show Chat Interface
function showChatInterface() {
    authContainer.classList.add('hidden');
    chatContainer.classList.remove('hidden');
    currentUsername.textContent = currentUser.displayName || currentUser.username;
    
    initializeSocket();
    loadRooms();
}

// Initialize Socket
function initializeSocket() {
    socket = io({
        auth: { token: authToken }
    });

    socket.on('connect', () => {
        console.log('Socket connected');
    });

    socket.on('message:new', (message) => {
        if (currentRoom && message.room === currentRoom._id) {
            displayMessage(message);
            scrollToBottom();
        }
    });

    socket.on('user:typing', (data) => {
        if (currentRoom && data.userId !== currentUser._id) {
            showTypingIndicator(data.username, data.isTyping);
        }
    });

    socket.on('room:user-joined', (data) => {
        if (currentRoom && data.message.room === currentRoom._id) {
            displayMessage(data.message);
        }
    });

    socket.on('room:user-left', (data) => {
        if (currentRoom && data.message.room === currentRoom._id) {
            displayMessage(data.message);
        }
    });

    socket.on('user:status', (data) => {
        console.log('User status update:', data);
    });

    socket.on('error', (error) => {
        console.error('Socket error:', error);
    });
}

// Load Rooms
async function loadRooms() {
    try {
        const response = await fetch(`${API_URL}/rooms`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            displayRooms(data.rooms);
        }
    } catch (error) {
        console.error('Error loading rooms:', error);
    }
}

// Display Rooms
function displayRooms(rooms) {
    roomsList.innerHTML = '';
    rooms.forEach(room => {
        const roomElement = document.createElement('div');
        roomElement.className = 'room-item';
        roomElement.dataset.roomId = room._id;
        roomElement.innerHTML = `
            <h4>${room.name}</h4>
            <p>${room.description || 'No description'}</p>
        `;
        roomElement.addEventListener('click', () => joinRoom(room));
        roomsList.appendChild(roomElement);
    });
}

// Join Room
async function joinRoom(room) {
    try {
        const response = await fetch(`${API_URL}/rooms/${room._id}/join`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            currentRoom = room;
            currentRoomName.textContent = room.name;
            roomMembersCount.textContent = `${room.members.length} members`;

            document.querySelectorAll('.room-item').forEach(item => {
                item.classList.remove('active');
            });
            document.querySelector(`[data-room-id="${room._id}"]`).classList.add('active');

            socket.emit('room:join', { roomId: room._id });
            
            loadMessages(room._id);
        }
    } catch (error) {
        console.error('Error joining room:', error);
    }
}

// Load Messages
async function loadMessages(roomId) {
    try {
        const response = await fetch(`${API_URL}/messages/${roomId}`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            messagesContainer.innerHTML = '';
            data.messages.forEach(message => displayMessage(message));
            scrollToBottom();
        }
    } catch (error) {
        console.error('Error loading messages:', error);
    }
}

// Display Message
function displayMessage(message) {
    const messageElement = document.createElement('div');
    const isOwnMessage = message.sender._id === currentUser._id;
    const isSystemMessage = message.type === 'system';

    messageElement.className = `message ${isOwnMessage ? 'own' : ''} ${isSystemMessage ? 'system' : ''}`;
    
    if (isSystemMessage) {
        messageElement.innerHTML = `
            <div class="message-content">
                <div class="message-text">${message.content}</div>
            </div>
        `;
    } else {
        messageElement.innerHTML = `
            <div class="message-avatar"></div>
            <div class="message-content">
                <div class="message-header">
                    <span class="message-sender">${message.sender.displayName || message.sender.username}</span>
                    <span class="message-time">${new Date(message.createdAt).toLocaleTimeString()}</span>
                </div>
                <div class="message-text">${escapeHtml(message.content)}</div>
            </div>
        `;
    }

    messagesContainer.appendChild(messageElement);
}

// Handle Send Message
function handleSendMessage() {
    const content = messageInput.value.trim();
    
    if (!content || !currentRoom) return;

    socket.emit('message:send', {
        content,
        roomId: currentRoom._id,
        type: 'text'
    });

    messageInput.value = '';
    messageInput.style.height = 'auto';
}

// Handle Message Key Press
function handleMessageKeyPress(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSendMessage();
    }
}

// Handle Typing
let typingTimeout;
function handleTyping() {
    if (!currentRoom) return;

    socket.emit('message:typing', {
        roomId: currentRoom._id,
        isTyping: true
    });

    clearTimeout(typingTimeout);
    typingTimeout = setTimeout(() => {
        socket.emit('message:typing', {
            roomId: currentRoom._id,
            isTyping: false
        });
    }, 1000);

    // Auto-resize textarea
    messageInput.style.height = 'auto';
    messageInput.style.height = messageInput.scrollHeight + 'px';
}

// Show Typing Indicator
let typingUsers = new Set();
function showTypingIndicator(username, isTyping) {
    if (isTyping) {
        typingUsers.add(username);
    } else {
        typingUsers.delete(username);
    }

    if (typingUsers.size > 0) {
        const text = Array.from(typingUsers).join(', ') + ' ' + 
                     (typingUsers.size === 1 ? 'is' : 'are') + ' typing...';
        document.querySelector('.typing-text').textContent = text;
        typingIndicator.classList.remove('hidden');
    } else {
        typingIndicator.classList.add('hidden');
    }
}

// Handle Create Room
async function handleCreateRoom(e) {
    e.preventDefault();
    
    const name = document.getElementById('room-name').value;
    const description = document.getElementById('room-description').value;
    const type = document.getElementById('room-type').value;

    try {
        const response = await fetch(`${API_URL}/rooms`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({ name, description, type })
        });

        if (response.ok) {
            createRoomModal.classList.add('hidden');
            createRoomForm.reset();
            loadRooms();
        }
    } catch (error) {
        console.error('Error creating room:', error);
    }
}

// Handle Logout
function handleLogout() {
    if (socket) {
        socket.disconnect();
    }
    
    localStorage.removeItem('authToken');
    authToken = null;
    currentUser = null;
    currentRoom = null;
    
    chatContainer.classList.add('hidden');
    authContainer.classList.remove('hidden');
}

// Helper Functions
function scrollToBottom() {
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
