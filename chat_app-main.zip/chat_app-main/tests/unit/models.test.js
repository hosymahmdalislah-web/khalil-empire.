const User = require('../../src/models/User');

describe('User Model', () => {
    describe('Password Hashing', () => {
        it('should hash password before saving', async () => {
            const user = new User({
                username: 'testuser',
                email: 'test@example.com',
                password: 'plainpassword'
            });

            expect(user.password).toBe('plainpassword');
            
            await user.validate();
            
            expect(user.password).not.toBe('plainpassword');
        });

        it('should compare passwords correctly', async () => {
            const user = new User({
                username: 'testuser',
                email: 'test@example.com',
                password: 'password123'
            });

            await user.save();

            const isMatch = await user.comparePassword('password123');
            expect(isMatch).toBe(true);

            const isNotMatch = await user.comparePassword('wrongpassword');
            expect(isNotMatch).toBe(false);
        });
    });

    describe('JSON Serialization', () => {
        it('should not include password in JSON', async () => {
            const user = new User({
                username: 'testuser',
                email: 'test@example.com',
                password: 'password123'
            });

            const json = user.toJSON();
            
            expect(json).not.toHaveProperty('password');
            expect(json).toHaveProperty('username');
            expect(json).toHaveProperty('email');
        });
    });

    describe('Validation', () => {
        it('should require username', async () => {
            const user = new User({
                email: 'test@example.com',
                password: 'password123'
            });

            let error;
            try {
                await user.validate();
            } catch (e) {
                error = e;
            }

            expect(error).toBeDefined();
            expect(error.errors.username).toBeDefined();
        });

        it('should require email', async () => {
            const user = new User({
                username: 'testuser',
                password: 'password123'
            });

            let error;
            try {
                await user.validate();
            } catch (e) {
                error = e;
            }

            expect(error).toBeDefined();
            expect(error.errors.email).toBeDefined();
        });

        it('should enforce minimum username length', async () => {
            const user = new User({
                username: 'ab',
                email: 'test@example.com',
                password: 'password123'
            });

            let error;
            try {
                await user.validate();
            } catch (e) {
                error = e;
            }

            expect(error).toBeDefined();
        });
    });
});
