const request = require('supertest');
const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const { app, server } = require('../../src/server');
const User = require('../../src/models/User');
const Room = require('../../src/models/Room');

let mongoServer;
let token;
let user;

beforeAll(async () => {
    mongoServer = await MongoMemoryServer.create();
    const mongoUri = mongoServer.getUri();
    await mongoose.connect(mongoUri);
});

afterAll(async () => {
    await mongoose.disconnect();
    await mongoServer.stop();
    server.close();
});

beforeEach(async () => {
    await User.deleteMany({});
    await Room.deleteMany({});

    const res = await request(app)
        .post('/api/auth/register')
        .send({
            username: 'testuser',
            email: 'test@example.com',
            password: 'password123'
        });
    
    token = res.body.token;
    user = res.body.user;
});

describe('Room API', () => {
    describe('POST /api/rooms', () => {
        it('should create a new room', async () => {
            const res = await request(app)
                .post('/api/rooms')
                .set('Authorization', `Bearer ${token}`)
                .send({
                    name: 'Test Room',
                    description: 'A test room',
                    type: 'public'
                });

            expect(res.statusCode).toBe(201);
            expect(res.body.room).toHaveProperty('name', 'Test Room');
            expect(res.body.room.members).toContain(user._id);
        });

        it('should fail without authentication', async () => {
            const res = await request(app)
                .post('/api/rooms')
                .send({
                    name: 'Test Room',
                    description: 'A test room'
                });

            expect(res.statusCode).toBe(401);
        });

        it('should fail with invalid data', async () => {
            const res = await request(app)
                .post('/api/rooms')
                .set('Authorization', `Bearer ${token}`)
                .send({
                    description: 'A test room'
                });

            expect(res.statusCode).toBe(400);
        });
    });

    describe('GET /api/rooms', () => {
        beforeEach(async () => {
            await Room.create({
                name: 'Room 1',
                type: 'public',
                createdBy: user._id,
                members: [user._id]
            });

            await Room.create({
                name: 'Room 2',
                type: 'private',
                createdBy: user._id,
                members: [user._id]
            });
        });

        it('should get all rooms', async () => {
            const res = await request(app)
                .get('/api/rooms')
                .set('Authorization', `Bearer ${token}`);

            expect(res.statusCode).toBe(200);
            expect(res.body.rooms).toHaveLength(2);
        });

        it('should filter rooms by type', async () => {
            const res = await request(app)
                .get('/api/rooms?type=public')
                .set('Authorization', `Bearer ${token}`);

            expect(res.statusCode).toBe(200);
            expect(res.body.rooms).toHaveLength(1);
            expect(res.body.rooms[0].type).toBe('public');
        });
    });

    describe('POST /api/rooms/:id/join', () => {
        let room;

        beforeEach(async () => {
            room = await Room.create({
                name: 'Test Room',
                type: 'public',
                createdBy: user._id,
                members: []
            });
        });

        it('should join a room', async () => {
            const res = await request(app)
                .post(`/api/rooms/${room._id}/join`)
                .set('Authorization', `Bearer ${token}`);

            expect(res.statusCode).toBe(200);
            
            const updatedRoom = await Room.findById(room._id);
            expect(updatedRoom.members).toContainEqual(expect.objectContaining({
                _id: mongoose.Types.ObjectId(user._id)
            }));
        });

        it('should not join if already a member', async () => {
            await request(app)
                .post(`/api/rooms/${room._id}/join`)
                .set('Authorization', `Bearer ${token}`);

            const res = await request(app)
                .post(`/api/rooms/${room._id}/join`)
                .set('Authorization', `Bearer ${token}`);

            expect(res.statusCode).toBe(400);
        });
    });
});
