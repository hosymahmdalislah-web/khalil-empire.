# Professional Real-Time Chat Application

[![Node.js](https://img.shields.io/badge/Node.js-14+-green.svg)](https://nodejs.org/)
[![MongoDB](https://img.shields.io/badge/MongoDB-4.0+-green.svg)](https://www.mongodb.com/)
[![Socket.IO](https://img.shields.io/badge/Socket.IO-4.6+-blue.svg)](https://socket.io/)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

A complete, production-ready real-time chat application built with Node.js, Socket.IO, and MongoDB. Perfect for CodeCanyon marketplace or enterprise deployment.

## ✨ Features

### Core Features
- 🔐 **User Authentication** - JWT-based secure authentication
- 💬 **Real-time Messaging** - Instant message delivery using Socket.IO
- 🏠 **Multi-room Chat** - Create and join multiple chat rooms
- 👥 **Private Messages** - Direct messaging between users
- 📱 **Responsive Design** - Works on desktop and mobile devices
- ⌨️ **Typing Indicators** - See when other users are typing
- 👤 **User Presence** - Online/offline status tracking
- 📝 **Message History** - Persistent message storage

### Admin Panel
- 📊 **Dashboard** - Overview statistics and analytics
- 👥 **User Management** - View, edit, and moderate users
- 🏠 **Room Management** - Create and manage chat rooms
- 💬 **Message Moderation** - Delete inappropriate messages
- 📈 **Real-time Analytics** - Track active users and rooms

### Developer Features
- 🔌 **RESTful API** - Complete REST API for all operations
- 🎨 **Embeddable Widget** - Easy-to-integrate chat widget
- 🧪 **Unit Tests** - Comprehensive test coverage
- 📚 **API Documentation** - Well-documented endpoints
- 🔒 **Security** - Rate limiting, helmet, CORS protection
- 📝 **Logging** - Winston-based logging system

## 🚀 Quick Start

### Prerequisites

- Node.js 14 or higher
- MongoDB 4.0 or higher
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone https://github.com/jirinevecny/chat_app.git
cd chat_app
```

2. Install dependencies:
```bash
npm install
```

3. Configure environment variables:
```bash
cp .env.example .env
```

Edit `.env` and configure your settings:
```env
PORT=3000
MONGODB_URI=mongodb://localhost:27017/chat_app
JWT_SECRET=your-super-secret-jwt-key
```

4. Seed the database (optional):
```bash
npm run seed
```

5. Start the server:
```bash
npm start
```

For development with auto-reload:
```bash
npm run dev
```

The application will be available at `http://localhost:3000`

## 📖 Usage

### Default Credentials (after seeding)

**Admin Account:**
- Username: `admin`
- Password: `admin123`

**Test Users:**
- Username: `john_doe` / Password: `password123`
- Username: `jane_smith` / Password: `password123`
- Username: `bob_wilson` / Password: `password123`

### Accessing the Application

- **Main Chat**: `http://localhost:3000`
- **Admin Panel**: `http://localhost:3000/admin`

## 🔌 API Documentation

### Authentication

#### Register User
```http
POST /api/auth/register
Content-Type: application/json

{
  "username": "john_doe",
  "email": "john@example.com",
  "password": "password123",
  "displayName": "John Doe"
}
```

#### Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "username": "john_doe",
  "password": "password123"
}
```

#### Get Profile
```http
GET /api/auth/profile
Authorization: Bearer <token>
```

### Rooms

#### Create Room
```http
POST /api/rooms
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "General Discussion",
  "description": "A room for general chat",
  "type": "public"
}
```

#### Get All Rooms
```http
GET /api/rooms
Authorization: Bearer <token>
```

#### Join Room
```http
POST /api/rooms/:id/join
Authorization: Bearer <token>
```

### Messages

#### Get Room Messages
```http
GET /api/messages/:roomId
Authorization: Bearer <token>
```

#### Send Message
```http
POST /api/messages
Authorization: Bearer <token>
Content-Type: application/json

{
  "content": "Hello, world!",
  "roomId": "room_id_here",
  "type": "text"
}
```

## 🎨 Embedding the Widget

Add this code to any webpage:

```html
<script src="http://localhost:3000/widget.js"></script>
<script>
  window.chatWidgetConfig = {
    roomId: 'your-room-id',
    position: 'bottom-right',
    primaryColor: '#4f46e5',
    width: '400px',
    height: '600px'
  };
  new ChatWidget(window.chatWidgetConfig);
</script>
```

## 🧪 Testing

Run all tests:
```bash
npm test
```

Run tests with coverage:
```bash
npm run test
```

Run tests in watch mode:
```bash
npm run test:watch
```

## 🏗️ Project Structure

```
chat_app/
├── src/
│   ├── config/           # Configuration files
│   ├── controllers/      # Request handlers
│   ├── models/          # Database models
│   ├── routes/          # API routes
│   ├── middleware/      # Custom middleware
│   ├── socket/          # Socket.IO handlers
│   ├── utils/           # Utility functions
│   └── server.js        # Main server file
├── public/
│   ├── admin/           # Admin panel
│   ├── widget/          # Embeddable widget
│   ├── css/             # Stylesheets
│   ├── js/              # Frontend JavaScript
│   └── index.html       # Main chat interface
├── tests/
│   ├── unit/            # Unit tests
│   └── integration/     # Integration tests
├── docs/                # Documentation
├── uploads/             # File uploads
├── package.json
└── README.md
```

## 🔒 Security Features

- JWT authentication
- Password hashing with bcrypt
- Rate limiting on API endpoints
- CORS configuration
- Helmet security headers
- Input validation with Joi
- XSS protection
- MongoDB injection prevention

## 📊 Technologies Used

- **Backend**: Node.js, Express.js
- **Real-time**: Socket.IO
- **Database**: MongoDB, Mongoose
- **Authentication**: JWT, bcrypt
- **Validation**: Joi
- **Security**: Helmet, CORS, express-rate-limit
- **Logging**: Winston
- **Testing**: Jest, Supertest
- **Frontend**: Vanilla JavaScript, HTML5, CSS3

## 🌟 Future Enhancements

- File sharing and image uploads
- Voice and video calls
- Message reactions and emojis
- User mentions and notifications
- Read receipts
- Message search functionality
- Multiple language support
- Dark mode theme
- Mobile apps (React Native)

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🤝 Support

For support, email support@chatapp.com or open an issue in the repository.

## 🙏 Acknowledgments

- Socket.IO for real-time communication
- MongoDB for flexible data storage
- Express.js for robust API framework
- All open-source contributors

---

**Made with ❤️ for CodeCanyon Marketplace**