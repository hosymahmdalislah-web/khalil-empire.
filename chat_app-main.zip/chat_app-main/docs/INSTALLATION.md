# Installation Guide

## System Requirements

- **Node.js**: Version 14.x or higher
- **MongoDB**: Version 4.0 or higher
- **RAM**: Minimum 512MB (2GB recommended for production)
- **Disk Space**: 100MB for application + storage for uploaded files and database

## Step-by-Step Installation

### 1. Install Node.js

**On Ubuntu/Debian:**
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
```

**On macOS:**
```bash
brew install node
```

**On Windows:**
Download and install from [nodejs.org](https://nodejs.org/)

Verify installation:
```bash
node --version
npm --version
```

### 2. Install MongoDB

**On Ubuntu/Debian:**
```bash
wget -qO - https://www.mongodb.org/static/pgp/server-6.0.asc | sudo apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/6.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-6.0.list
sudo apt-get update
sudo apt-get install -y mongodb-org
sudo systemctl start mongod
sudo systemctl enable mongod
```

**On macOS:**
```bash
brew tap mongodb/brew
brew install mongodb-community
brew services start mongodb-community
```

**On Windows:**
Download and install from [mongodb.com](https://www.mongodb.com/try/download/community)

Verify installation:
```bash
mongosh --version
```

### 3. Clone the Repository

```bash
git clone https://github.com/jirinevecny/chat_app.git
cd chat_app
```

### 4. Install Dependencies

```bash
npm install
```

This will install all required Node.js packages defined in `package.json`.

### 5. Configure Environment Variables

```bash
cp .env.example .env
```

Edit `.env` file with your preferred text editor:

```bash
nano .env
```

**Required Configuration:**

```env
# Server Configuration
PORT=3000
NODE_ENV=production

# MongoDB Configuration
MONGODB_URI=mongodb://localhost:27017/chat_app

# JWT Secret (CHANGE THIS!)
JWT_SECRET=your-unique-secret-key-here-change-this

# Admin Credentials
ADMIN_USERNAME=admin
ADMIN_PASSWORD=your-secure-admin-password

# CORS (Add your domain)
ALLOWED_ORIGINS=http://localhost:3000,https://yourdomain.com

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100

# File Upload
MAX_FILE_SIZE=5242880
UPLOAD_PATH=./uploads
```

**Security Notes:**
- Change `JWT_SECRET` to a strong random string
- Use a strong password for admin account
- Update `ALLOWED_ORIGINS` with your actual domain

### 6. Create Required Directories

```bash
mkdir -p logs uploads
```

### 7. Seed Initial Data (Optional)

```bash
npm run seed
```

This creates:
- Admin user (username: admin)
- Sample users
- Sample rooms
- Sample messages

### 8. Start the Application

**Production Mode:**
```bash
npm start
```

**Development Mode (with auto-reload):**
```bash
npm run dev
```

The application will be available at `http://localhost:3000`

### 9. Verify Installation

1. Open your browser and navigate to `http://localhost:3000`
2. You should see the login page
3. Login with default credentials:
   - Username: `admin`
   - Password: `admin123` (or what you set in .env)

## Production Deployment

### Using PM2 (Process Manager)

1. Install PM2:
```bash
npm install -g pm2
```

2. Start the application:
```bash
pm2 start src/server.js --name chat-app
```

3. Configure PM2 to start on system boot:
```bash
pm2 startup
pm2 save
```

4. Monitor the application:
```bash
pm2 logs chat-app
pm2 monit
```

### Using Docker (Optional)

1. Create a `Dockerfile`:
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
```

2. Create `docker-compose.yml`:
```yaml
version: '3.8'
services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - MONGODB_URI=mongodb://mongo:27017/chat_app
    depends_on:
      - mongo
  mongo:
    image: mongo:6
    volumes:
      - mongo-data:/data/db
volumes:
  mongo-data:
```

3. Run with Docker Compose:
```bash
docker-compose up -d
```

### Nginx Reverse Proxy

Create `/etc/nginx/sites-available/chat-app`:

```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    location /socket.io/ {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

Enable the site:
```bash
sudo ln -s /etc/nginx/sites-available/chat-app /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

## Troubleshooting

### MongoDB Connection Error

**Error:** `MongoNetworkError: failed to connect to server`

**Solution:**
1. Check if MongoDB is running:
   ```bash
   sudo systemctl status mongod
   ```
2. Start MongoDB:
   ```bash
   sudo systemctl start mongod
   ```

### Port Already in Use

**Error:** `EADDRINUSE: address already in use`

**Solution:**
1. Change the PORT in `.env` file
2. Or kill the process using port 3000:
   ```bash
   lsof -ti:3000 | xargs kill
   ```

### Permission Errors

**Error:** `EACCES: permission denied`

**Solution:**
```bash
sudo chown -R $USER:$USER .
chmod -R 755 .
```

### Module Not Found

**Error:** `Cannot find module 'xyz'`

**Solution:**
```bash
rm -rf node_modules package-lock.json
npm install
```

## Next Steps

After successful installation:
1. Read the [Configuration Guide](CONFIGURATION.md)
2. Explore the [API Documentation](API.md)
3. Learn about [Widget Integration](WIDGET.md)
4. Review [Security Best Practices](SECURITY.md)

## Support

If you encounter any issues during installation, please:
1. Check the troubleshooting section above
2. Review the logs in `logs/` directory
3. Open an issue on GitHub with detailed error messages
