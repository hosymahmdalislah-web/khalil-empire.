# API Documentation

## Base URL

```
http://localhost:3000/api
```

All API endpoints are prefixed with `/api`.

## Authentication

Most endpoints require authentication using JWT (JSON Web Token).

Include the token in the Authorization header:
```
Authorization: Bearer <your-token>
```

## Response Format

### Success Response
```json
{
  "message": "Success message",
  "data": {}
}
```

### Error Response
```json
{
  "error": "Error message",
  "details": []
}
```

## Endpoints

### Authentication

#### Register User

**POST** `/auth/register`

Create a new user account.

**Request Body:**
```json
{
  "username": "string (3-30 chars, required)",
  "email": "string (valid email, required)",
  "password": "string (min 6 chars, required)",
  "displayName": "string (optional, max 50 chars)"
}
```

**Response:** `201 Created`
```json
{
  "message": "User registered successfully",
  "token": "jwt-token-string",
  "user": {
    "_id": "user-id",
    "username": "john_doe",
    "email": "john@example.com",
    "displayName": "John Doe",
    "role": "user",
    "status": "offline",
    "createdAt": "2024-01-01T00:00:00.000Z"
  }
}
```

#### Login

**POST** `/auth/login`

Authenticate and receive a JWT token.

**Request Body:**
```json
{
  "username": "string (required)",
  "password": "string (required)"
}
```

**Response:** `200 OK`
```json
{
  "message": "Login successful",
  "token": "jwt-token-string",
  "user": {
    "_id": "user-id",
    "username": "john_doe",
    "displayName": "John Doe",
    "status": "online"
  }
}
```

#### Get Profile

**GET** `/auth/profile`

Get the current user's profile.

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "user": {
    "_id": "user-id",
    "username": "john_doe",
    "email": "john@example.com",
    "displayName": "John Doe",
    "role": "user",
    "status": "online"
  }
}
```

#### Update Profile

**PUT** `/auth/profile`

Update the current user's profile.

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "displayName": "string (optional)",
  "avatar": "string (optional)",
  "status": "online|offline|away (optional)"
}
```

**Response:** `200 OK`
```json
{
  "message": "Profile updated successfully",
  "user": {
    "_id": "user-id",
    "username": "john_doe",
    "displayName": "John Doe Updated",
    "status": "online"
  }
}
```

### Rooms

#### Create Room

**POST** `/rooms`

Create a new chat room.

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "name": "string (required, max 100 chars)",
  "description": "string (optional, max 500 chars)",
  "type": "public|private (optional, default: public)",
  "maxMembers": "number (optional, default: 50)"
}
```

**Response:** `201 Created`
```json
{
  "message": "Room created successfully",
  "room": {
    "_id": "room-id",
    "name": "General Discussion",
    "description": "A room for general chat",
    "type": "public",
    "createdBy": "user-id",
    "members": ["user-id"],
    "maxMembers": 50,
    "isActive": true,
    "createdAt": "2024-01-01T00:00:00.000Z"
  }
}
```

#### Get All Rooms

**GET** `/rooms`

Get all active rooms.

**Headers:** `Authorization: Bearer <token>`

**Query Parameters:**
- `type` (optional): Filter by room type (`public` or `private`)

**Response:** `200 OK`
```json
{
  "rooms": [
    {
      "_id": "room-id",
      "name": "General",
      "description": "General discussion",
      "type": "public",
      "createdBy": {
        "_id": "user-id",
        "username": "admin",
        "displayName": "Administrator"
      },
      "members": ["user-id-1", "user-id-2"],
      "createdAt": "2024-01-01T00:00:00.000Z"
    }
  ]
}
```

#### Get Room Details

**GET** `/rooms/:id`

Get details of a specific room.

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "room": {
    "_id": "room-id",
    "name": "General",
    "description": "General discussion",
    "type": "public",
    "createdBy": {
      "_id": "user-id",
      "username": "admin",
      "displayName": "Administrator",
      "avatar": ""
    },
    "members": [
      {
        "_id": "user-id",
        "username": "john_doe",
        "displayName": "John Doe",
        "avatar": "",
        "status": "online"
      }
    ]
  }
}
```

#### Join Room

**POST** `/rooms/:id/join`

Join a chat room.

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "message": "Joined room successfully",
  "room": {
    "_id": "room-id",
    "name": "General",
    "members": ["user-id-1", "user-id-2"]
  }
}
```

#### Leave Room

**POST** `/rooms/:id/leave`

Leave a chat room.

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "message": "Left room successfully"
}
```

#### Delete Room

**DELETE** `/rooms/:id`

Delete a room (owner or admin only).

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "message": "Room deleted successfully"
}
```

### Messages

#### Get Room Messages

**GET** `/messages/:roomId`

Get messages for a specific room.

**Headers:** `Authorization: Bearer <token>`

**Query Parameters:**
- `limit` (optional): Number of messages to return (default: 50)
- `before` (optional): Get messages before this timestamp

**Response:** `200 OK`
```json
{
  "messages": [
    {
      "_id": "message-id",
      "content": "Hello, world!",
      "type": "text",
      "sender": {
        "_id": "user-id",
        "username": "john_doe",
        "displayName": "John Doe",
        "avatar": ""
      },
      "room": "room-id",
      "isEdited": false,
      "isDeleted": false,
      "createdAt": "2024-01-01T00:00:00.000Z"
    }
  ]
}
```

#### Send Message

**POST** `/messages`

Send a message to a room.

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "content": "string (required, max 5000 chars)",
  "roomId": "string (required)",
  "type": "text|file|image (optional, default: text)",
  "recipientId": "string (optional, for private messages)"
}
```

**Response:** `201 Created`
```json
{
  "message": "Message sent successfully",
  "data": {
    "_id": "message-id",
    "content": "Hello, world!",
    "type": "text",
    "sender": {
      "_id": "user-id",
      "username": "john_doe",
      "displayName": "John Doe"
    },
    "room": "room-id",
    "createdAt": "2024-01-01T00:00:00.000Z"
  }
}
```

#### Edit Message

**PUT** `/messages/:id`

Edit a message (own messages only).

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "content": "string (required)"
}
```

**Response:** `200 OK`
```json
{
  "message": "Message updated successfully",
  "data": {
    "_id": "message-id",
    "content": "Updated message",
    "isEdited": true
  }
}
```

#### Delete Message

**DELETE** `/messages/:id`

Delete a message (own messages or admin).

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "message": "Message deleted successfully"
}
```

### Admin

All admin endpoints require admin role.

#### Get Statistics

**GET** `/admin/stats`

Get dashboard statistics.

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "stats": {
    "totalUsers": 100,
    "activeUsers": 25,
    "totalRooms": 10,
    "totalMessages": 5000
  },
  "recentUsers": [
    {
      "_id": "user-id",
      "username": "new_user",
      "createdAt": "2024-01-01T00:00:00.000Z"
    }
  ]
}
```

#### Get All Users

**GET** `/admin/users`

Get all users with pagination.

**Headers:** `Authorization: Bearer <token>`

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Users per page (default: 20)

**Response:** `200 OK`
```json
{
  "users": [...],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 100,
    "pages": 5
  }
}
```

#### Update User

**PUT** `/admin/users/:userId`

Update user role or status.

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "role": "user|admin (optional)",
  "isActive": "boolean (optional)"
}
```

**Response:** `200 OK`
```json
{
  "message": "User updated successfully",
  "user": {...}
}
```

#### Delete User

**DELETE** `/admin/users/:userId`

Deactivate a user.

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "message": "User deactivated successfully"
}
```

## Error Codes

| Code | Description |
|------|-------------|
| 200 | Success |
| 201 | Created |
| 400 | Bad Request (validation error) |
| 401 | Unauthorized (invalid/missing token) |
| 403 | Forbidden (insufficient permissions) |
| 404 | Not Found |
| 429 | Too Many Requests (rate limit exceeded) |
| 500 | Internal Server Error |

## Rate Limiting

API endpoints are rate-limited to prevent abuse:
- **Window**: 15 minutes
- **Max Requests**: 100 per window per IP

When rate limit is exceeded, you'll receive a 429 status code.

## Best Practices

1. Always store JWT tokens securely (HttpOnly cookies or secure storage)
2. Refresh tokens before they expire
3. Handle errors gracefully
4. Implement retry logic for network failures
5. Use pagination for large datasets
6. Validate input on client side before sending requests
