# Widget Integration Guide

The chat widget allows you to easily embed the chat functionality into any website.

## Quick Start

Add these two script tags to your HTML:

```html
<!-- Load the widget script -->
<script src="http://localhost:3000/widget.js"></script>

<!-- Initialize the widget -->
<script>
  window.chatWidgetConfig = {
    roomId: 'your-room-id-here',
    position: 'bottom-right',
    primaryColor: '#4f46e5'
  };
  new ChatWidget(window.chatWidgetConfig);
</script>
```

## Configuration Options

### Basic Configuration

```javascript
window.chatWidgetConfig = {
  // Required: Room ID to connect to
  roomId: 'room-id-here',
  
  // Position of the widget button
  // Options: 'bottom-right', 'bottom-left', 'top-right', 'top-left'
  position: 'bottom-right',
  
  // Primary color for the widget theme
  primaryColor: '#4f46e5',
  
  // Widget dimensions
  width: '400px',
  height: '600px'
};
```

### Advanced Configuration

```javascript
window.chatWidgetConfig = {
  roomId: 'room-id-here',
  position: 'bottom-right',
  primaryColor: '#4f46e5',
  width: '400px',
  height: '600px',
  
  // Custom theme
  theme: 'light', // or 'dark'
  
  // Auto-open on page load
  autoOpen: false,
  
  // Show unread message count
  showUnreadCount: true,
  
  // Custom greeting message
  greetingMessage: 'Hi! How can we help you?',
  
  // Minimum width for responsive design
  minWidth: '320px',
  
  // Maximum height for responsive design
  maxHeight: '90vh'
};
```

## Complete Example

Here's a complete HTML page with the widget integrated:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Website with Chat</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        h1 {
            color: #333;
        }
    </style>
</head>
<body>
    <h1>Welcome to My Website</h1>
    <p>This is your website content. The chat widget will appear in the bottom right corner.</p>
    
    <!-- Chat Widget -->
    <script src="http://localhost:3000/widget.js"></script>
    <script>
        window.chatWidgetConfig = {
            roomId: 'general-room-id',
            position: 'bottom-right',
            primaryColor: '#4f46e5',
            width: '400px',
            height: '600px'
        };
        new ChatWidget(window.chatWidgetConfig);
    </script>
</body>
</html>
```

## Getting a Room ID

To get a room ID:

1. Login to the chat application as admin
2. Create a room or use an existing one
3. Copy the room ID from the URL or from the API response

Alternatively, use the API to create a room programmatically:

```javascript
async function createChatRoom() {
    const response = await fetch('http://localhost:3000/api/rooms', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer YOUR_ADMIN_TOKEN'
        },
        body: JSON.stringify({
            name: 'Customer Support',
            description: 'Support chat room',
            type: 'public'
        })
    });
    
    const data = await response.json();
    console.log('Room ID:', data.room._id);
}
```

## Styling Customization

### Custom Colors

```javascript
window.chatWidgetConfig = {
    roomId: 'your-room-id',
    primaryColor: '#ff6b6b',      // Main theme color
    secondaryColor: '#4ecdc4',    // Secondary elements
    textColor: '#2d3436',         // Text color
    backgroundColor: '#f8f9fa'    // Background color
};
```

### Custom CSS

You can add custom CSS to override widget styles:

```html
<style>
    /* Override widget button */
    .chat-widget-button {
        width: 70px !important;
        height: 70px !important;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
    }
    
    /* Override widget header */
    .chat-widget-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
    }
    
    /* Override message bubbles */
    .chat-widget-message.own .chat-widget-message-content {
        background: #667eea !important;
    }
</style>
```

## Events and Callbacks

The widget emits events that you can listen to:

```javascript
const widget = new ChatWidget({
    roomId: 'your-room-id',
    onReady: function() {
        console.log('Widget is ready');
    },
    onOpen: function() {
        console.log('Widget opened');
    },
    onClose: function() {
        console.log('Widget closed');
    },
    onMessage: function(message) {
        console.log('New message received:', message);
    },
    onError: function(error) {
        console.error('Widget error:', error);
    }
});
```

## API Methods

After initializing the widget, you can control it programmatically:

```javascript
const widget = new ChatWidget(window.chatWidgetConfig);

// Open the widget
widget.open();

// Close the widget
widget.close();

// Toggle the widget
widget.toggle();

// Send a message programmatically
widget.sendMessage('Hello from code!');

// Get unread message count
const unreadCount = widget.getUnreadCount();

// Destroy the widget
widget.destroy();
```

## Responsive Design

The widget is responsive by default. For mobile devices:

```javascript
window.chatWidgetConfig = {
    roomId: 'your-room-id',
    
    // Mobile-specific settings
    mobileBreakpoint: 768,
    mobileWidth: '100%',
    mobileHeight: '100%',
    mobilePosition: 'bottom-right'
};
```

## Multiple Widgets

You can have multiple widgets on the same page:

```html
<script>
    // Support chat
    new ChatWidget({
        roomId: 'support-room-id',
        position: 'bottom-right',
        primaryColor: '#4f46e5'
    });
    
    // Sales chat
    new ChatWidget({
        roomId: 'sales-room-id',
        position: 'bottom-left',
        primaryColor: '#10b981'
    });
</script>
```

## Authentication

### Pre-authenticated Users

If you already have a user token:

```javascript
window.chatWidgetConfig = {
    roomId: 'your-room-id',
    token: 'user-jwt-token',
    skipLogin: true
};
```

### Custom Login

Implement custom login UI:

```javascript
window.chatWidgetConfig = {
    roomId: 'your-room-id',
    customLogin: true,
    onLoginRequired: function(callback) {
        // Show your custom login form
        const token = await yourCustomLogin();
        callback(token);
    }
};
```

## Security Considerations

1. **CORS Configuration**: Make sure your domain is allowed in the server's CORS settings
2. **Token Security**: Never expose admin tokens in client-side code
3. **Rate Limiting**: The widget respects API rate limits
4. **Data Validation**: All messages are validated on the server

## Troubleshooting

### Widget not appearing

1. Check browser console for errors
2. Verify the script URL is correct
3. Ensure roomId is valid
4. Check CORS settings

### Connection issues

1. Verify server is running
2. Check network tab in browser dev tools
3. Ensure WebSocket connections are allowed
4. Check firewall/proxy settings

### Styling issues

1. Check for CSS conflicts
2. Use `!important` to override styles
3. Verify color values are valid
4. Test in different browsers

## Best Practices

1. **Performance**: Load the widget asynchronously
   ```html
   <script async src="http://localhost:3000/widget.js"></script>
   ```

2. **Error Handling**: Always implement error callbacks
   ```javascript
   onError: function(error) {
       console.error('Chat error:', error);
       // Show user-friendly error message
   }
   ```

3. **User Experience**: Don't auto-open the widget on every page load
   ```javascript
   autoOpen: false,
   rememberState: true  // Remember if user closed it
   ```

4. **Accessibility**: Ensure the widget is keyboard accessible
   ```javascript
   enableKeyboardNavigation: true,
   ariaLabel: 'Chat support widget'
   ```

## Examples

### E-commerce Site

```javascript
new ChatWidget({
    roomId: 'customer-support',
    primaryColor: '#ff6b6b',
    position: 'bottom-right',
    greetingMessage: 'Need help with your order?',
    onMessage: function(msg) {
        // Track chat interactions
        analytics.track('chat_message', {
            content: msg.content
        });
    }
});
```

### SaaS Application

```javascript
new ChatWidget({
    roomId: 'technical-support',
    token: currentUser.chatToken,
    skipLogin: true,
    primaryColor: '#667eea',
    showUnreadCount: true,
    onReady: function() {
        // Send user context
        this.setContext({
            userId: currentUser.id,
            plan: currentUser.subscription.plan,
            accountAge: currentUser.accountAge
        });
    }
});
```

### Blog/Content Site

```javascript
new ChatWidget({
    roomId: 'community-chat',
    primaryColor: '#10b981',
    position: 'bottom-left',
    width: '350px',
    height: '500px',
    autoOpen: false,
    rememberState: true
});
```

## Support

For widget-related issues:
- Check the [documentation](https://github.com/jirinevecny/chat_app)
- Open an issue on GitHub
- Contact support@chatapp.com
